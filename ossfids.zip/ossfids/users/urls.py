from django.urls import path
from . import views
from django.contrib.auth.views import LoginView
from .forms import CustomAuthenticationForm
from .views import (
    generate_daily_schedule_view,
    FlightTemplateListView, 
    FlightTemplateCreateView, 
    FlightTemplateUpdateView,
    FlightTemplateDeleteView,
    user_menu,
    FlightForTemplateCreateView,
    export_daily_plan_to_docx
)

urlpatterns = [
    path('user_menu/', user_menu, name='user_menu'),
    path('inftablo/', views.InfTabloListView.as_view(), name='inftablo_list'),
    path('inftablo/add/', views.InfTabloCreateView.as_view(), name='inftablo_add'),
    path('inftablo/<int:pk>/edit/', views.InfTabloUpdateView.as_view(), name='inftablo_edit'),
    path('inftablo/update_status/', views.update_status, name='update_status'),

    path('generate-daily-schedule/', generate_daily_schedule_view, name='generate_daily_schedule'),

    path('flight-templates/', FlightTemplateListView.as_view(), name='flight_template_list'),
    path('flight-templates/add/', FlightTemplateCreateView.as_view(), name='flight_template_add'),
    path('flight-templates/edit/<int:pk>/', FlightTemplateUpdateView.as_view(), name='flight_template_edit'),
    path('flight-templates/delete/<int:pk>/', FlightTemplateDeleteView.as_view(), name='flight_template_delete'),
    path('add_flights/', FlightForTemplateCreateView.as_view(), name='add_flights'),

    path('export-docx/', export_daily_plan_to_docx, name='export_daily_plan_to_docx'),

    path('', LoginView.as_view(authentication_form=CustomAuthenticationForm, next_page='user_menu'), name='login'),
    path('logout/', views.logout_view, name='logout'),
]

# Стандартные библиотеки
import json
from datetime import datetime, timedelta, date

# Django импорты
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth.mixins import LoginRequiredMixin
from django.contrib import messages
from django.db.models import Q
from django.http import HttpResponse
from django.shortcuts import render, redirect
from django.urls import reverse_lazy
from django.utils import timezone
from django.utils.timezone import now
from django.views.decorators.csrf import csrf_protect
from django.views.decorators.http import require_POST
from django.views.generic import ListView, CreateView, UpdateView, DeleteView
from django.contrib.messages.views import SuccessMessageMixin
from django.core.paginator import Paginator

from django.http import JsonResponse
from django.template.loader import render_to_string
from django.views.generic.edit import FormView

# Локальные импорты
from app.models import InfTablo, Status, FlightTemplate, DIRECTION, FlightForTemplate
from .forms import InfTabloForm, DateFilterForm, SelectDateForm, FlightTemplateForm, FlightForTemplateForm

# Общие переменные
today = datetime.today().date()
tomorrow = today + timedelta(days=1)


# Авторизация
def login_view(request):
    # Если пользователь уже авторизован, перенаправляем его
    if request.user.is_authenticated:
        return redirect('user_menu')  # Перенаправление на "user_menu"

    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            messages.success(request, "Вы успешно вошли в систему.")

            # Перенаправление на страницу из параметра "next" или на "user_menu"
            next_url = request.GET.get('next', 'user_menu')
            return redirect(next_url)
        else:
            messages.error(request, "Неверный логин или пароль.")
    else:
        form = AuthenticationForm()

    return render(request, 'registration/login.html', {'form': form})


def logout_view(request):
    logout(request)
    messages.success(request, "Вы успешно вышли из системы.")
    return redirect('login')


# Управление рейсами
class BaseInfTabloView(SuccessMessageMixin):
    model = InfTablo
    form_class = InfTabloForm
    success_url = reverse_lazy('inftablo_list')
    success_message = "Информация успешно сохранена!"


class InfTabloListView(LoginRequiredMixin, BaseInfTabloView, ListView):
    template_name = 'inftablo_list.html'
    context_object_name = 'inftablos'

    login_url = '/users/'  # Укажите URL страницы входа (опционально)
    redirect_field_name = 'next'  # Параметр, куда сохраняется исходный URL (по умолчанию 'next')

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        today = timezone.now().date()

        # Получаем дату из формы
        form = DateFilterForm(self.request.GET)
        filter_date = today
        if form.is_valid() and form.cleaned_data['selected_date']:
            filter_date = form.cleaned_data['selected_date']

        # Определяем направление
        direction = self.request.GET.get('direction', 'dep')

        # Фильтруем записи
        departures = InfTablo.objects.filter(direction='dep', date1=filter_date).order_by('date1')
        arrivals = InfTablo.objects.filter(direction='arr', date1=filter_date).order_by('date1')

        if direction == 'arr':
            context['arrivals'] = arrivals
        else:
            context['departures'] = departures

        # Добавляем данные в контекст
        context.update({
            'form': form,
            'status_choices': Status.objects.all(),
            'direction': direction,
            'todays_date': today,  # Передача текущей даты в контекст
            'selected_date': filter_date.strftime('%Y-%m-%d'),
        })
        return context


@login_required(login_url='/users/')  # Гарантирует, что доступ к user_menu возможен только после входа
def user_menu(request):
    return render(request, 'user_menu.html')  # Шаблон user_menu


class InfTabloCreateView(LoginRequiredMixin, BaseInfTabloView, CreateView):
    template_name = 'inftablo_form.html'

    login_url = '/users/'  # Укажите URL страницы входа (опционально)
    redirect_field_name = 'next'  # Параметр, куда сохраняется исходный URL (по умолчанию 'next')


class InfTabloUpdateView(LoginRequiredMixin, BaseInfTabloView, UpdateView):
    template_name = 'inftablo_form.html'

    login_url = '/users/'  # Укажите URL страницы входа (опционально)
    redirect_field_name = 'next'  # Параметр, куда сохраняется исходный URL (по умолчанию 'next')

    def form_valid(self, form):
        if 'save_as_new' in self.request.POST:
            form.instance.pk = None
            form.instance.id = None
        return super().form_valid(form)


@csrf_protect
def update_status(request):
    inftablo_id = request.POST.get("inftablo_id")
    status_id = request.POST.get("status_id")
    try:
        inftablo = InfTablo.objects.get(id=inftablo_id)
        new_status = Status.objects.get(id=status_id)
        inftablo.status = new_status
        inftablo.save()
        return redirect('inftablo_list')
    except (InfTablo.DoesNotExist, Status.DoesNotExist):
        return redirect('inftablo_list')


@login_required(login_url='/users/')
def generate_daily_schedule_view(request):
    if request.method == "POST":
        form = SelectDateForm(request.POST)
        if form.is_valid():
            selected_date = form.cleaned_data.get('date') or timezone.now().date()
            selected_day = selected_date.weekday() + 1

            templates = FlightTemplate.objects.filter(
                season_start__lte=selected_date,
                season_end__gte=selected_date,
                weekdays__contains=str(selected_day)
            )

            created_count = 0
            for template in templates:
                if not InfTablo.objects.filter(flight=template.flight.flight, date1=selected_date).exists():
                    InfTablo.objects.create(
                        direction=template.direction,
                        airline=template.flight.airline,
                        flight=template.flight.flight,
                        destination=template.flight.destination,
                        date1=selected_date,
                        time1=template.time
                    )
                    created_count += 1

            messages.success(request, f"Сформировано {created_count} рейсов на {selected_date}.")
            return redirect('inftablo_list')
    else:
        form = DateFilterForm(initial={'date': timezone.now().date()})

    return render(request, "generate_daily_schedule.html", {"form": form})


# Шаблоны рейсов
class FlightTemplateListView(LoginRequiredMixin, ListView):
    model = FlightTemplate
    template_name = 'app/flight_template_list.html'
    context_object_name = 'flight_templates'
    paginate_by = 10

    login_url = '/users/'  # Укажите URL страницы входа (опционально)
    redirect_field_name = 'next'  # Параметр, куда сохраняется исходный URL (по умолчанию 'next')


class FlightTemplateCreateView(LoginRequiredMixin, SuccessMessageMixin, CreateView):
    model = FlightTemplate
    form_class = FlightTemplateForm
    template_name = 'flight_template_form.html'
    success_url = reverse_lazy('flight_template_list')
    success_message = "Шаблон успешно создан!"

    login_url = '/users/'  # Укажите URL страницы входа (опционально)
    redirect_field_name = 'next'  # Параметр, куда сохраняется исходный URL (по умолчанию 'next')

    def get_initial(self):
        initial = super().get_initial()
        last_template = FlightTemplate.objects.order_by('-id').first()
        if last_template:
            initial.update({
                'season_start': last_template.season_start,
                'season_end': last_template.season_end,
            })
        return initial


class FlightTemplateUpdateView(LoginRequiredMixin, SuccessMessageMixin, UpdateView):
    model = FlightTemplate
    form_class = FlightTemplateForm
    template_name = 'flight_template_form.html'
    success_url = reverse_lazy('flight_template_list')
    success_message = "Шаблон успешно обновлён!"

    login_url = '/users/'  # Укажите URL страницы входа (опционально)
    redirect_field_name = 'next'  # Параметр, куда сохраняется исходный URL (по умолчанию 'next')


class FlightTemplateDeleteView(LoginRequiredMixin, SuccessMessageMixin, DeleteView):
    model = FlightTemplate
    template_name = 'flight_template_confirm_delete.html'
    success_url = reverse_lazy('flight_template_list')
    success_message = "Шаблон успешно удалён!"

    login_url = '/users/'  # Укажите URL страницы входа (опционально)
    redirect_field_name = 'next'  # Параметр, куда сохраняется исходный URL (по умолчанию 'next')




    

class InfTabloCombinedView(LoginRequiredMixin, BaseInfTabloView, ListView):
    model = InfTablo
    template_name = 'inftablo_combined.html'
    context_object_name = 'inftablos'

    login_url = '/users/'  # Укажите URL страницы входа (опционально)
    redirect_field_name = 'next'  # Параметр, куда сохраняется исходный URL (по умолчанию 'next')

    def get_queryset(self):
        return InfTablo.objects.all()

    def get_filter_date(self):
        today = timezone.now().date()
        date_filter_form = DateFilterForm(self.request.GET)
        if date_filter_form.is_valid() and date_filter_form.cleaned_data['selected_date']:
            return date_filter_form.cleaned_data['selected_date']
        return today

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        filter_date = self.get_filter_date()
        direction = self.request.GET.get('direction')

        departures = InfTablo.objects.filter(direction='dep', date1=filter_date).order_by('date1', '-time1')
        arrivals = InfTablo.objects.filter(direction='arr', date1=filter_date).order_by('date1', '-time1')

        context['departures'] = departures if direction != 'arr' else None
        context['arrivals'] = arrivals if direction != 'dep' else None
        context.update({
            'date_filter_form': DateFilterForm(self.request.GET),
            'inftablo_form': InfTabloForm(),
            'status_choices': Status.objects.all(),
            'direction': direction,
        })
        return context

    def process_form(self, request):
        pk = request.POST.get('pk')
        if not pk:
            form = InfTabloForm(request.POST)
        else:
            try:
                instance = InfTablo.objects.get(pk=pk)
                form = InfTabloForm(request.POST, instance=instance)
            except (InfTablo.DoesNotExist, ValueError):
                return {'success': False, 'errors': 'Рейс не найден'}

        if form.is_valid():
            form.save()
            return {'success': True, 'message': 'Рейс успешно сохранен'}
        return {'success': False, 'errors': form.errors}

    def post(self, request, *args, **kwargs):
        response = self.process_form(request)
        if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            return JsonResponse(response)
        return redirect('inftablo_combined')

    def get_form(self, pk=None):
        """
        Возвращает форму InfTabloForm.
        Если указан pk, возвращает форму с объектом (для редактирования),
        иначе возвращает пустую форму (для создания нового объекта).
        """
        if pk:
            try:
                instance = InfTablo.objects.get(pk=pk)
                form = InfTabloForm(instance=instance)
                return form
            except (InfTablo.DoesNotExist, ValueError):
                return None
        return InfTabloForm()

    def get(self, request, *args, **kwargs):
        if request.headers.get('X-Requested-With') == 'XMLHttpRequest' and 'pk' in request.GET:
            form = self.get_form(request.GET.get('pk'))
            if form:
                form_html = render_to_string('partials/form.html', {'form': form}, request=request)
                return JsonResponse({'form_html': form_html})
            return JsonResponse({'error': 'Рейс не найден.'}, status=404)
        return super().get(request, *args, **kwargs)


from django.views.generic.edit import CreateView
from django.urls import reverse_lazy

class FlightForTemplateCreateView(LoginRequiredMixin, CreateView):
    model = FlightForTemplate
    form_class = FlightForTemplateForm
    template_name = 'flight_create.html'  # Указываем шаблон
    # fields = ['airline', 'flight', 'destination']  # Поля, которые будут отображаться в форме
    success_url = reverse_lazy('add_flights')
    login_url = '/users/'  # Укажите URL страницы входа (опционально)
    redirect_field_name = 'next'  # Параметр, куда сохраняется исходный URL (по умолчанию 'next')


# export to docx

from django.http import HttpResponse
from django.utils.timezone import now
from docx import Document
from docx.enum.section import WD_ORIENT
from docx.shared import Mm, Pt, RGBColor
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from app.models import InfTablo
from .forms import SelectDateForm

@login_required(login_url='/users/')
def export_daily_plan_to_docx(request):
    # Получаем текущую дату (на случай, если ничего не выбрано)
    today = now().date()

    # Получаем дату из формы
    form = SelectDateForm(request.GET)
    filter_date = today
    if form.is_valid():
        filter_date = form.cleaned_data['selected_date']

    # Определяем направление
    direction = request.GET.get('direction', 'dep')

    # Фильтруем данные
    if direction == 'arr':
        tablo_entries = InfTablo.objects.filter(direction='arr', date1=filter_date).order_by('time1')
        direction_name = "Прилеты"
    else:
        tablo_entries = InfTablo.objects.filter(direction='dep', date1=filter_date).order_by('time1')
        direction_name = "Вылеты"

    # Создаём Word-документ
    document = Document()
    
    # Форматируем дату в формате dd.month.yyyy
    months = {
        1: "января", 2: "февраля", 3: "марта", 4: "апреля", 5: "мая", 6: "июня",
        7: "июля", 8: "августа", 9: "сентября", 10: "октября", 11: "ноября", 12: "декабря"
    }
    formatted_date = f"{filter_date.day} {months[filter_date.month]} {filter_date.year}"

    # Заголовок документа
    heading = document.add_heading(f'Суточный план ({direction_name}) на {formatted_date}', level=1)

    # Добавляем отступ после заголовка
    paragraph = document.add_paragraph()  # Создаем пустой абзац для отступа
    paragraph.add_run("")  # Добавляем пробел для пустого места

    # Устанавливаем формат A4 и альбомную ориентацию
    section = document.sections[0]
    section.orientation = WD_ORIENT.LANDSCAPE
    section.page_width = Mm(297)
    section.page_height = Mm(210)

    # Настраиваем поля страницы
    section.left_margin = Mm(15)
    section.right_margin = Mm(15)
    section.top_margin = Mm(20)
    section.bottom_margin = Mm(20)

    # Добавляем таблицу
    table = document.add_table(rows=1, cols=5)
    table.style = 'Table Grid'

    # Применяем Times New Roman ко всему документу
    for paragraph in document.paragraphs:
        for run in paragraph.runs:
            run.font.name = 'Times New Roman'
            run.font.size = Pt(12)  # Опционально: Установить размер шрифта
            r = run._element
            r.rPr.rFonts.set(qn('w:eastAsia'), 'Times New Roman')  # Для совместимости

    # Заголовки таблицы
    headers = ['Время', 'Направление', 'Рейс', 'Статус', 'Примечание']
    hdr_cells = table.rows[0].cells
    for i, header in enumerate(headers):
        cell = hdr_cells[i]
        cell.text = header

        # Форматируем шрифт заголовка таблицы
        cell_paragraph = cell.paragraphs[0]
        cell_paragraph.runs[0].bold = True  # Жирный шрифт
        cell_paragraph.runs[0].font.size = Pt(12)  # Размер шрифта

        # Устанавливаем фон ячеек заголовка
        shading_elm = OxmlElement("w:shd")  # Создаём элемент заливки
        shading_elm.set(qn("w:val"), "clear")  # Тип заливки
        shading_elm.set(qn("w:color"), "auto")  # Цвет текста
        shading_elm.set(qn("w:fill"), "D9D9D9")  # Цвет фона (светло-серый)

        # Добавляем элемент заливки в свойства ячейки
        tc_pr = cell._element.get_or_add_tcPr()
        tc_pr.append(shading_elm)


    # Заполняем таблицу данными
    for entry in tablo_entries:
        run.font.name = 'Times New Roman'
        row_cells = table.add_row().cells
        row_cells[0].text = entry.time1.strftime('%H:%M') if entry.time1 else '—'
        row_cells[1].text = str(entry.destination) if entry.destination else '—'
        row_cells[2].text = str(entry.flight) if entry.flight else '—'
        # row_cells[3].text = entry.status.name if entry.status else '—'
        # row_cells[4].text = ', '.join([str(stoika) for stoika in entry.stoika.all()]) or '—'

    # Добавляем подпись
    document.add_paragraph(f'Дата экспорта: {now().strftime("%d.%m.%Y %H:%M")}')

    # Возвращаем файл в HTTP-ответе
    response = HttpResponse(content_type='application/vnd.openxmlformats-officedocument.wordprocessingml.document')
    response['Content-Disposition'] = f'attachment; filename="daily_plan_{direction}_{filter_date}.docx"'
    document.save(response)
    return response